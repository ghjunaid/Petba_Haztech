<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Petba</title>
    <style>
        h1 {
            margin-top: 20%;
            display: flex;
            justify-content: center;
            color: rgb(190, 190, 190);
            align-items: center;
        }
    </style>
</head>
<body>
    <h1>
        P e t b a   B a c k e n d   A P I
    </h1>
</body>
</html><?php /**PATH C:\xampp1\htdocs\apilaravel\resources\views/welcome.blade.php ENDPATH**/ ?>