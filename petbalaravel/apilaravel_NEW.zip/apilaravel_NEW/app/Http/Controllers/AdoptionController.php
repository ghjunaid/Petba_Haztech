<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class AdoptionController
{
    public function adoptionInterest(Request $request)
    {
        $email = $request->input('email');
        $token = $request->input('token');
        $cId = $request->input('c_id');

        try {
            $out = internalUserDetails($email); // Token validation helper
            $ck_id = $out->customer_id;
            $ck_tkn = $out->token;

            if ($cId == $ck_id && $token == $ck_tkn) {
                // Fetch adopt records with interested count (including zero) for given c_id
                $adoptionWithInterest = DB::table('adopt')
                    ->leftJoin(DB::raw('(SELECT p_id, COUNT(id) as t FROM interested GROUP BY p_id) as a'), 'a.p_id', '=', 'adopt.adopt_id')
                    ->select('adopt.adopt_id', 'adopt.c_id', 'adopt.name', 'adopt.gender', 'adopt.dob', 'adopt.img1', 'adopt.breed', DB::raw('COALESCE(a.t, 0) as t'), 'adopt.city')
                    ->where('adopt.c_id', '=', $cId)
                    ->get();

                // Fetch adopt records where c_id doesn't match
                $adoptionWithoutInterest = DB::table('adopt')
                    ->select('adopt.adopt_id', 'adopt.c_id', 'adopt.name', 'adopt.gender', 'adopt.dob', 'adopt.img1', 'adopt.breed')
                    ->where('adopt.c_id', '!=', $cId)
                    ->get();

                return response()->json([
                    'adoptionInterest' => $adoptionWithInterest,
                    'adoptionWithoutInterest' => $adoptionWithoutInterest
                ]);
            } else {
                return response()->json(['error' => 'Invalid user credentials'], 401);
            }
        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }



   public function listAdoption(Request $request)
    {
        $cityId = $request->input('city_id');
        $lastPet = $request->input('lastPet', 0);
        $ageSort = $request->input('ageSort', false);
        $locationSort = $request->input('locationSort', false);
        $newSort = $request->input('newSort', false);
        $latitudeSelf = $request->input('latitude');
        $longitudeSelf = $request->input('longitude');
        $animalTypeName = $request->input('animalTypeName');
        $breed = $request->input('breed');
        $genderArray = $request->input('gender');
        $color = $request->input('color');

        $limit = 6;
        $offset = $lastPet ? $lastPet : 0;

        // Base query
        $query = DB::table('adopt as a')
            ->leftJoin('animal as b', 'a.animal_typ', '=', 'b.animal_id')
            ->leftJoin('breed as c', 'a.breed', '=', 'c.id')  // Use c.id based on your schema
            ->select(
                'a.adopt_id',
                'a.c_id',
                'a.name',
                'a.gender',
                'a.dob',
                'a.img1',
                'a.city',
                'b.name as animalName',
                'c.name as breed'
            )
            ->where('a.petFlag', 2);

        // Filters

        if ($genderArray && is_array($genderArray) && count($genderArray) > 0) {
            $query->whereIn('a.gender', $genderArray);
        }

        if ($animalTypeName && is_array($animalTypeName) && count($animalTypeName) > 0) {
            $query->whereIn('a.animal_typ', $animalTypeName);
        }

        if ($breed && is_array($breed) && count($breed) > 0) {
            $query->whereIn('a.breed', $breed);
        }

        if ($color && is_array($color) && count($color) > 0) {
            // Left join colors only if filtering by color
            $query->leftJoin('colors as co', 'co.id', '=', 'a.color')
                ->whereIn('co.id', $color);
        }

        if ($cityId) {
            $query->where('a.city_id', $cityId);
        }

        // Sorting & pagination

        if ($newSort) {
            $query->orderByDesc('a.adopt_id');
        } elseif ($ageSort) {
            $query->orderByDesc('a.dob');
        } elseif ($locationSort && $latitudeSelf && $longitudeSelf) {
            // Use raw SQL for distance sorting
            $sql = "
                SELECT a.adopt_id, a.c_id, a.name, a.gender, a.dob, a.img1, a.city,
                    b.name as animalName, c.name as breed,
                    (6371 * acos(
                        cos(radians(?)) * cos(radians(a.latitude)) *
                        cos(radians(a.longitude) - radians(?)) +
                        sin(radians(?)) * sin(radians(a.latitude))
                    )) AS Distance
                FROM adopt a
                LEFT JOIN animal b ON a.animal_typ = b.animal_id
                LEFT JOIN breed c ON a.breed = c.id
                WHERE a.petFlag = 2
                AND a.city_id = ?
                ORDER BY Distance ASC
                LIMIT ? OFFSET ?
            ";

            $results = DB::select($sql, [
                $latitudeSelf,
                $longitudeSelf,
                $latitudeSelf,
                $cityId,
                $limit,
                $offset
            ]);

            return response()->json(['listadopt' => $results]);
        } else {
            // Default sorting by adopt_id descending if no sorting specified
            $query->orderByDesc('a.adopt_id');
        }

        $query->limit($limit)->offset($offset);

        try {
            $results = $query->get();

            return response()->json(['listadopt' => $results]);
        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }

    public function listMyAdoption(Request $request)
    {
        $email = $request->input('email');
        $token = $request->input('token');
        $cId = $request->input('c_id');

        try {
            $out = internalUserDetails($email); // Token validation helper
            $ck_id = $out->customer_id;
            $ck_tkn = $out->token;

            if ($cId == $ck_id && $token == $ck_tkn) {
                $query = DB::table('adopt as a')
                    ->leftJoin('animal as b', 'a.animal_typ', '=', 'b.animal_id')
                    ->leftJoin('breed as c', 'c.id', '=', 'a.breed')
                    ->leftJoin('colors as d', 'd.id', '=', 'a.color')
                    ->select(
                        'a.adopt_id',
                        'a.c_id',
                        'a.img1',
                        'a.name',
                        DB::raw("IF(a.animal_typ = 0, a.animalTypeName, b.name) AS animalTypeName"),
                        'b.name as animalName',
                        'a.gender',
                        'a.dob',
                        DB::raw("IF(a.breed = 0, a.breedName, c.name) AS breed"),
                        'a.city'
                    )
                    ->where('a.petFlag', '=', 2)
                    ->where('a.c_id', '=', $cId)
                    ->get();

                return response()->json(['listMyadoption' => $query]);
            } else {
                return response()->json(['error' => 'Invalid user credentials'], 401);
            }
        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }




    public function addPetAdoption(Request $request)
    {
        $data = $request->all();

        $email = $data['email'];
        $token = $data['token'];
        $c_id = $data['c_id'];

        try {
            $out = internalUserDetails($email); // Token validation
            $ck_id = $out->customer_id;
            $ck_tkn = $out->token;

            if ($c_id == $ck_id && $token == $ck_tkn) {

                $name = $data['name'];
                $animal = $data['animal'];
                $animalName = $data['animalName'] ?? null;
                $gender = $data['gender'];
                $color = $data['color'];
                $breed = $data['breed'];
                $breedName = $data['breedName'] ?? null;
                $note = $data['note'] ?? null;
                $city = $data['city'];
                $city_id = $data['city_id'];
                $longitude = $data['long'];
                $latitude = $data['lat'];
                $anti_rbs = $data['anti_rbs'] ?? null;
                $viral = $data['viral'] ?? null;
                $petFlag = 2;
                $DoB = $data['dob'];

                $images = [
                    'img1' => $data['img1'] ?? null,
                    'img2' => $data['img2'] ?? null,
                    'img3' => $data['img3'] ?? null,
                    'img4' => $data['img4'] ?? null,
                    'img5' => $data['img5'] ?? null,
                    'img6' => $data['img6'] ?? null,
                ];

                $imgPaths = [];

                foreach ($images as $key => $img) {
                    if (!empty($img)) {
                        $filename = 'adoptionImage/mypet_' . $c_id . '_' . $key . '_' . time() . '.jpg';
                        $img = str_replace(['data:image/jpeg;base64,', 'data:image/jpg;base64,'], '', $img);
                        $img = base64_decode($img);
                        Storage::disk('public')->put($filename, $img);
                        $imgPaths[$key] = '/storage/' . $filename;
                    } else {
                        $imgPaths[$key] = '';
                    }
                }

                $adoptData = [
                    'c_id' => $c_id,
                    'petFlag' => $petFlag,
                    'name' => $name,
                    'animal_typ' => $animal,
                    'gender' => $gender,
                    'dob' => $DoB,
                    'breed' => $breed,
                    'color' => $color,
                    'anti_rbs' => $anti_rbs,
                    'viral' => $viral,
                    'note' => $note,
                    'city' => $city,
                    'city_id' => $city_id,
                    'longitude' => $longitude,
                    'latitude' => $latitude,
                ];

                $id = DB::table('adopt')->insertGetId($adoptData);

                foreach ($imgPaths as $key => $path) {
                    if (!empty($path)) {
                        DB::table('adopt')->where('adopt_id', $id)->update([$key => $path]);
                    }
                }

                if ($animalName) {
                    DB::table('adopt')->where('adopt_id', $id)->update(['animalTypeName' => $animalName]);
                }

                if ($breedName) {
                    DB::table('adopt')->where('adopt_id', $id)->update(['breedName' => $breedName]);
                }

                return response()->json(['adopt' => 'added to db successfully'], 200);
            } else {
                return response()->json(['error' => 'Invalid user credentials'], 401);
            }
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }


   public function petAdoptionDetails(Request $request)
{
    $data = $request->all();

    $email = $data['email'];
    $token = $data['token'];
    $c_id = $data['c_id'];
    $adopt_id = $data['adopt_id'];

    try {
        $out = internalUserDetails($email); // Token validation
        $ck_id = $out->customer_id;
        $ck_tkn = $out->token;

        if ($c_id == $ck_id && $token == $ck_tkn) {

            $adoptionDetails = DB::table('adopt as a')
                ->leftJoin('animal as b', 'a.animal_typ', '=', 'b.animal_id')
                ->leftJoin('breed as c', 'c.id', '=', 'a.breed')
                ->leftJoin('colors as d', 'd.id', '=', 'a.color')
                ->leftJoin('oc_customer as cust', 'a.c_id', '=', 'cust.customer_id')
                ->select(
                    'a.adopt_id',
                    'a.c_id',
                    'a.petFlag',
                    'a.img1',
                    'a.img2',
                    'a.img3',
                    'a.img4',
                    'a.img5',
                    'a.img6',
                    'a.name',
                    'cust.telephone',
                    DB::raw("IF(a.animal_typ != '0', b.name, a.animalTypeName) as animalTypeName"),
                    'a.gender',
                    'a.dob',
                    DB::raw("IF(a.breed != '0', c.name, a.breedName) as breed"),
                    'd.color',
                    'a.anti_rbs',
                    'a.viral',
                    'a.note',
                    'a.city',
                    'a.longitude',
                    'a.latitude',
                    'a.date_added'
                )
                ->where('a.adopt_id', $adopt_id)
                ->first();

            return response()->json(['adoptdetails' => $adoptionDetails], 200);

        } else {
            return response()->json(['error' => 'Invalid user credentials'], 401);
        }

    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
}




    public function updatePetAdoption(Request $request)
    {
        $data = $request->all();

        $email = $data['email'];
        $token = $data['token'];
        $c_id = $data['c_id'];

        try {
            $out = internalUserDetails($email); // Token validation
            $ck_id = $out->customer_id;
            $ck_tkn = $out->token;

            if ($c_id == $ck_id && $token == $ck_tkn) {
                $city_id = $data['city_id'];
                $name = $data['name'];
                $animal_typ = $data['animal_typ'];
                $animalTypeName = $data['animalTypeName'];
                $gender = $data['gender'];
                $color = $data['color'];
                $breed = $data['breed'];
                $breedName = $data['breedName'];
                $note = $data['note'];
                $dob = $data['dob'];
                $adopt_id = $data['adopt_id'];
                $viral = $data['viral'];
                $anti_rbs = $data['anti_rbs'];
                $latitude = $data['latitude'];
                $longitude = $data['longitude'];
                $city = $data['city'];

                $ss = "";

                if (!is_null($longitude) && !is_null($latitude)) {
                    $ss .= ", longitude='" . $longitude . "', latitude='" . $latitude . "'";
                }

                if (is_numeric($breed)) {
                    if ($breed == '0') {
                        $ss .= ", breed='" . $breed . "', breedName='" . $breedName . "'";
                    } else {
                        $ss .= ", breed='" . $breed . "'";
                    }
                }

                if (is_numeric($animal_typ)) {
                    if ($animal_typ == '0') {
                        $ss .= ", animal_typ='" . $animal_typ . "', animalTypeName='" . $animalTypeName . "'";
                    } else {
                        $ss .= ", animal_typ='" . $animal_typ . "'";
                    }
                }

                if (is_numeric($color)) {
                    $ss .= ", color='" . $color . "'";
                }

                $sql = "UPDATE adopt SET c_id=:c_id, name=:name, gender=:gender, dob=:dob, city=:city, city_id=:city_id" . $ss . ", note=:note, viral=:viral, anti_rbs=:anti_rbs WHERE adopt_id=:adopt_id";

                DB::update($sql, [
                    'c_id' => $c_id,
                    'name' => $name,
                    'gender' => $gender,
                    'dob' => $dob,
                    'city' => $city,
                    'city_id' => $city_id,
                    'note' => $note,
                    'viral' => $viral,
                    'anti_rbs' => $anti_rbs,
                    'adopt_id' => $adopt_id,
                ]);

                return response()->json(['updateadopt' => $data], 200);

            } else {
                return response()->json(['error' => 'Invalid user credentials'], 401);
            }

        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }



    public function deleteAdoptPet(Request $request)
    {
        $data = $request->all();

        $email = $data['email'];
        $token = $data['token'];
        $adopt_id = $data['adopt_id'];
        $c_id = $data['c_id'];

        try {
            $out = internalUserDetails($email); // Token validation
            $ck_id = $out->customer_id;
            $ck_token = $out->token;

            if ($c_id == $ck_id && $token == $ck_token) {

                $deleted = DB::table('adopt')
                    ->where('adopt_id', $adopt_id)
                    ->where('c_id', $c_id)
                    ->delete();

                if ($deleted) {
                    return response()->json(['deleteadoptpet' => 'Deleted successfully'], 200);
                } else {
                    return response()->json(['error' => 'Record not found'], 404);
                }

            } else {
                return response()->json(['error' => 'Invalid user credentials'], 401);
            }

        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }


    public function updatePetAdoptionImage(Request $request)
    {
        $data = $request->all();
        $imgNumber = $data['imgNumber'];
        $adopt_id = $data['adopt_id'];
        $image = $data['img'];
        $token = $data['token'] ?? null;
        $customer_id = $data['customer_id'] ?? null;
        $email = $data['email'] ?? null;

        try {
            // Token validation
            if (!$token || !$customer_id) {
                return response()->json(['error' => 'Token and customer_id are required'], 400);
            }

            $user = internalUserDetails($email); // your existing method
            if (!$user || $user->token !== $token) {
                return response()->json(['error' => 'Unauthorized access - invalid token'], 401);
            }

            // Ownership check: only allow if user owns the adoption post
            $adoption = DB::table('adopt')
                ->where('adopt_id', $adopt_id)
                ->first();

            if (!$adoption) {
                return response()->json(['error' => 'Adoption post not found'], 404);
            }

            if ((int) $adoption->c_id !== (int) $customer_id) {
                return response()->json(['error' => 'Unauthorized access - not the owner'], 403);
            }

            // save the image
            if ($image) {
                // Ensure directory exists
                $directory = public_path('storage/adoptionImage');
                if (!File::exists($directory)) {
                    File::makeDirectory($directory, 0755, true);
                }

                $targetPath = 'storage/adoptionImage/mypet_' . $adopt_id . '_' . time() . '.jpg';

                $imageData = str_replace(['data:image/jpeg;base64,', 'data:image/jpg;base64,'], '', $image);
                $imageData = str_replace(' ', '+', $imageData); // fix base64 format
                $imageData = base64_decode($imageData);

                File::put(public_path($targetPath), $imageData);
                $imageURL = url($targetPath);

                if ($imgNumber) {
                    $updated = DB::table('adopt')
                        ->where('adopt_id', $adopt_id)
                        ->update(['img' . $imgNumber => $imageURL]);

                    if ($updated) {
                        return response()->json(['Image' => 'Uploaded in img' . $imgNumber], 200);
                    } else {
                        return response()->json(['error' => 'No rows updated'], 400);
                    }
                }
            } else {
                return response()->json(['error' => 'Image not provided'], 400);
            }

        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }

    
    public function updateRemovePetAdoptionImage(Request $request)
    {
        $data = $request->all();
        $imgNumber = $data['imgNumber'];
        $adopt_id = $data['adopt_id'];

        try {
            if ($imgNumber) {
                // Update the specified image column (img1, img2, etc.) to an empty string
                $affectedRows = DB::table('adopt')
                    ->where('adopt_id', $adopt_id)
                    ->update(['img' . $imgNumber => '']);

                if ($affectedRows) {
                    return response()->json(['Image' => 'Removed from img' . $imgNumber], 200);
                } else {
                    return response()->json(['error' => 'No rows updated'], 400);
                }
            }
        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }

    public function adoptionName(Request $request)
    {
        // Validate incoming request
        $data = $request->validate([
            'p_id' => 'required|string',
        ]);

        $p_id = $data['p_id'];

        try {
            // Fetch adoption details
            $adoption = DB::table('adopt')
                ->select('img1', 'name')
                ->where('adopt_id', $p_id)
                ->first();

            // Return JSON response
            return response()->json(['adoptionname' => $adoption]);
        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }

    

    public function addForAdoption(Request $request)
    {
        // Validate the incoming JSON body
        $data = $request->validate([
            'petId' => 'required|integer',
            'petFlag' => 'required|string'
        ]);

        try {
            DB::table('adopt')
                ->where('adopt_id', $data['petId'])
                ->update(['petFlag' => $data['petFlag']]);

            return response()->json(['Updated' => 'Pet has been updated']);
        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }

    public function getInterestedPeople(Request $request)
    {
        $data = $request->all();

        $email = $data['email'];
        $token = $data['token'];
        $c_id = $data['c_id'];
        $adopt_id = $data['adopt_id'];

        try {
            $out = internalUserDetails($email); // Token validation
            $ck_id = $out->customer_id;
            $ck_tkn = $out->token;

            if ($c_id == $ck_id && $token == $ck_tkn) {

                // 1. Get the specific adoption post (optional, not used in this response)
                $adoptPost = DB::table('adopt')
                    ->where('adopt_id', $adopt_id)
                    ->first();

                // 2. Get the interested people who match that post
                $interestedPeople = DB::table('oc_customer as a')
                    ->join('interested as b', 'a.customer_id', '=', 'b.c_id')
                    ->where('b.p_id', $adopt_id)
                    ->select('a.customer_id', 'a.email', 'a.token', 'a.telephone', 'b.p_id')
                    ->get();

                return response()->json([
                    'interested' => $interestedPeople,
                    // 'adopt_post' => $adoptPost // Uncomment if needed
                ], 200);

            } else {
                return response()->json(['error' => 'Invalid user credentials'], 401);
            }

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to fetch interested people',
                'message' => $e->getMessage()
            ], 500);
        }
    }


}
