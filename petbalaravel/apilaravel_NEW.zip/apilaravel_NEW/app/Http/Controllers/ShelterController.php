<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ShelterController
{
public function shelterList(Request $request)
{
    $data = $request->json()->all();
    $c_id = $data['c_id'];
    $tab = $data['tab'];
    $lastPet = $data['offset'] ?? 0;
    $latitude = $data['latitude'];
    $longitude = $data['longitude'];
    $locationSort = $data['locationSort'] ?? false;
    $rateSort = $data['rateSort'] ?? false;
    $alphaSort = $data['alphaSort'] ?? false;
    $city_id = $data['city_id'] ?? null;
    $filters = $data['filter'] ?? [];

    try {
        if ($tab == 'a') {
            $joinFilter = '';
            $whereConditions = [];
            $bindings = [];

            if (!empty($filters)) {
                $joinFilter = " INNER JOIN shelter_to_filter ON shelter_to_filter.shelter_id = a.id ";
                $placeholders = implode(',', array_fill(0, count($filters), '?'));
                $whereConditions[] = "shelter_to_filter.filter_id IN ($placeholders)";
                $bindings = array_merge($bindings, $filters);
            }

            if ($city_id) {
                $whereConditions[] = "a.city_id = ?";
                $bindings[] = $city_id;
            }

            $whereClause = '';
            if (!empty($whereConditions)) {
                $whereClause = ' WHERE ' . implode(' AND ', $whereConditions);
            }

            $sql = "SELECT a.id, a.name, a.img1, a.phoneNumber, a.latitude, a.longitude, 
                           a.fee, a.rating, a.open_time, a.close_time, a.owner,
                           (6371 * ACOS(
                               COS(RADIANS(?)) * COS(RADIANS(a.latitude)) 
                               * COS(RADIANS(a.longitude) - RADIANS(?))
                               + SIN(RADIANS(?)) * SIN(RADIANS(a.latitude))
                           )) AS Distance,
                           c.city
                    FROM shelter AS a
                    INNER JOIN cities AS c ON a.city_id = c.city_id
                    $joinFilter
                    $whereClause";

            if ($locationSort) {
                $sql .= " ORDER BY Distance ASC";
            } elseif ($rateSort) {
                $sql .= " ORDER BY a.rating DESC";
            } elseif ($alphaSort) {
                $sql .= " ORDER BY a.name ASC";
            } else {
                $sql .= " ORDER BY Distance ASC"; // default order
            }

            $sql .= " LIMIT 6 OFFSET ?";

            // Add latitude, longitude, latitude again (for Distance calculation), and offset at the end of bindings
            $bindings[] = $latitude;
            $bindings[] = $longitude;
            $bindings[] = $latitude;
            $bindings[] = $lastPet;

            $shelters = DB::select($sql, $bindings);

            return response()->json(['shelterlist' => $shelters]);
        } 
        elseif ($tab == 'b') {
            // Your existing code for tab b (no change)
            $limit = 6;

            $sql = "SELECT id, name, img1 as img, address, paid, phoneNumber, verified,
                    (((RADIANS(ACOS(SIN(RADIANS(?)) * SIN(RADIANS(latitude)) + COS(RADIANS(?)) * COS(RADIANS(latitude)) * COS(RADIANS(? - longitude))))) * 60 * 1.1515) * 1.609344) AS Distance
                    FROM shelter
                    WHERE c_id = ?
                    ORDER BY Distance ASC
                    LIMIT $limit OFFSET ?";

            $bindings = [$latitude, $latitude, $longitude, $c_id, $lastPet];

            $shelters = DB::select($sql, $bindings);

            return response()->json(['myShelter' => $shelters]);
        }
    } catch (\PDOException $e) {
        return response()->json(['error' => ['text' => $e->getMessage()]]);
    }
}



    public function shelterDetails(Request $request)
    {
        $data = $request->validate([
            'id' => 'required|integer',
        ]);

        $id = $data['id'];

        try {
            // Get shelter details with review count using a subquery in select
            $shelter = DB::table('shelter as a')
                ->select(
                    'a.*',
                    DB::raw("(SELECT COUNT(*) FROM shelter_reviews WHERE shelter_id = {$id}) as review_count")
                )
                ->where('a.id', $id)
                ->first();

            // Get latest 2 reviews for the shelter
            $reviews = DB::table('shelter_reviews')
                ->where('shelter_id', $id)
                ->orderBy('time', 'DESC')
                ->limit(2)
                ->get();

            // Get all filters linked to this shelter
            $filters = DB::table('shelterFilters as f')
                ->join('shelter_to_filter as sf', 'f.filter_id', '=', 'sf.filter_id')
                ->where('sf.shelter_id', $id)
                ->select('f.*')
                ->get();

            // Get all filter groups (independent)
            $filterGroups = DB::table('shelterFilterGroup')->get();

            return response()->json([
                'shelterDetails' => $shelter,
                'reviews' => $reviews,
                'filters' => $filters,
                'filterGroups' => $filterGroups,
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => ['text' => $e->getMessage()]], 500);
        }
    }


    public function addShelter(Request $request)
{
    $data = $request->validate([
        'c_id' => 'required|integer',
        'name' => 'required|string',
        'address' => 'required|string',
        'latitude' => 'required|numeric',
        'longitude' => 'required|numeric',
        'description' => 'nullable|string',
        'paid' => 'required|boolean',
        'acceptlimit' => 'nullable|integer',
        'phoneNumber' => 'nullable|string',
        'owner' => 'required|string',   // ✅ added validation for owner
        'img1' => 'nullable|string',
        'img2' => 'nullable|string',
        'img3' => 'nullable|string',
        'img4' => 'nullable|string',
    ]);

    $imageArray = [
        1 => $data['img1'] ?? null,
        2 => $data['img2'] ?? null,
        3 => $data['img3'] ?? null,
        4 => $data['img4'] ?? null,
    ];

    try {
        // Prepare the shelter data (including owner now ✅)
        $shelterData = [
            'c_id' => $data['c_id'],
            'name' => $data['name'],
            'address' => $data['address'],
            'paid' => $data['paid'],
            'phoneNumber' => $data['phoneNumber'] ?? null,
            'latitude' => $data['latitude'],
            'longitude' => $data['longitude'],
            'acceptlimit' => $data['acceptlimit'] ?? null,
            'description' => $data['description'] ?? null,
            'owner' => $data['owner'],   // ✅ include owner in insert
        ];

        // Insert shelter data and get the new ID
        $shelterId = DB::table('shelter')->insertGetId($shelterData);

        // Process and save images if provided
        $imgUpdates = [];
        foreach ($imageArray as $index => $imageData) {
            if ($imageData) {
                // Remove base64 prefix and decode
                $cleanedImage = preg_replace('/^data:image\/\w+;base64,/', '', $imageData);
                $decodedImage = base64_decode($cleanedImage);

                // Build a unique file path
                $fileName = 'shelter_Pet_' . $data['c_id'] . '_' . $index . '_' . time() . '.jpg';
                $targetPath = 'adoptionImage/' . $fileName;

                // Save the image file using Laravel Storage
                Storage::put($targetPath, $decodedImage);

                // Prepare image URL for DB update
                $imgUpdates['img' . $index] = '/petbaopencart/api/' . $targetPath;
            }
        }

        // Update the shelter record with image URLs if any images were saved
        if (!empty($imgUpdates)) {
            DB::table('shelter')->where('id', $shelterId)->update($imgUpdates);
        }

        return response()->json(['addShelter' => [
            'success' => true,
            'id' => $shelterId,
            'data' => $data
        ]]);
    } catch (\Exception $e) {
        return response()->json(['error' => ['text' => $e->getMessage()]], 500);
    }
}


}